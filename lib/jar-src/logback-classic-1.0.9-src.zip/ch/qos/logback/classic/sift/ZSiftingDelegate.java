package ch.qos.logback.classic.sift;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class ZSiftingDelegate
  extends ch.qos.logback.core.spi.ContextAwareBase  implements
    groovy.lang.GroovyObject {
public ZSiftingDelegate
(java.lang.String key, java.lang.String value) {}
public  ch.qos.logback.core.Appender appender(java.lang.String name, java.lang.Class clazz) { return (ch.qos.logback.core.Appender)null;}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  java.lang.String getKey() { return (java.lang.String)null;}
public  void setKey(java.lang.String value) { }
public  java.lang.String getValue() { return (java.lang.String)null;}
public  void setValue(java.lang.String value) { }
public  ch.qos.logback.core.Appender appender(java.lang.String name, java.lang.Class clazz, groovy.lang.Closure closure) { return (ch.qos.logback.core.Appender)null;}
}
