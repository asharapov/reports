package ch.qos.logback.classic.sift;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class GSiftingAppender
  extends ch.qos.logback.core.AppenderBase  implements
    ch.qos.logback.classic.gaffer.ConfigurationContributor,    groovy.lang.GroovyObject {
protected ch.qos.logback.core.sift.AppenderTracker<ch.qos.logback.classic.spi.ILoggingEvent> appenderTracker;
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  ch.qos.logback.core.sift.Discriminator<ch.qos.logback.classic.spi.ILoggingEvent> getDiscriminator() { return (ch.qos.logback.core.sift.Discriminator)null;}
public  void setDiscriminator(ch.qos.logback.core.sift.Discriminator<ch.qos.logback.classic.spi.ILoggingEvent> value) { }
public  groovy.lang.Closure getBuilderClosure() { return (groovy.lang.Closure)null;}
public  void setBuilderClosure(groovy.lang.Closure value) { }
public  int getNopaWarningCount() { return (int)0;}
public  void setNopaWarningCount(int value) { }
public  java.util.Map<java.lang.String, java.lang.String> getMappings() { return (java.util.Map)null;}
@java.lang.Override() public  void start() { }
@java.lang.Override() public  void stop() { }
protected  long getTimestamp(ch.qos.logback.classic.spi.ILoggingEvent event) { return (long)0;}
public  ch.qos.logback.core.Appender buildAppender(java.lang.String value) { return (ch.qos.logback.core.Appender)null;}
@java.lang.Override() public  void append(java.lang.Object object) { }
public  ch.qos.logback.core.helpers.NOPAppender<ch.qos.logback.classic.spi.ILoggingEvent> buildNOPAppender(java.lang.String discriminatingValue) { return (ch.qos.logback.core.helpers.NOPAppender)null;}
public  void build() { }
public  void sift(groovy.lang.Closure clo) { }
public  ch.qos.logback.core.sift.AppenderTracker getAppenderTracker() { return (ch.qos.logback.core.sift.AppenderTracker)null;}
public  java.lang.String getDiscriminatorKey() { return (java.lang.String)null;}
}
