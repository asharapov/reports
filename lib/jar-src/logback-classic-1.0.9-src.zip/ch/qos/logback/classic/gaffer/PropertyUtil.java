package ch.qos.logback.classic.gaffer;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class PropertyUtil
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public static  boolean hasAdderMethod(java.lang.Object obj, java.lang.String name) { return false;}
public static  ch.qos.logback.classic.gaffer.NestingType nestingType(java.lang.Object obj, java.lang.String name) { return (ch.qos.logback.classic.gaffer.NestingType)null;}
public static  void attach(ch.qos.logback.classic.gaffer.NestingType nestingType, java.lang.Object component, java.lang.Object subComponent, java.lang.String name) { }
public static  java.lang.String transformFirstLetter(java.lang.String s, groovy.lang.Closure closure) { return (java.lang.String)null;}
public static  java.lang.String upperCaseFirstLetter(java.lang.String s) { return (java.lang.String)null;}
}
