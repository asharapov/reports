package org.echosoft.common.cli.display;

/**
 * @author Anton Sharapov
 */
public interface CellValueFormatter {

    public String format(Object obj);
}
