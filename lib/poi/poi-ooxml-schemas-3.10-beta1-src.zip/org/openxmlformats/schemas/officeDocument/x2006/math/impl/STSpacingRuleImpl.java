/*
 * XML Type:  ST_SpacingRule
 * Namespace: http://schemas.openxmlformats.org/officeDocument/2006/math
 * Java type: org.openxmlformats.schemas.officeDocument.x2006.math.STSpacingRule
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.officeDocument.x2006.math.impl;
/**
 * An XML ST_SpacingRule(@http://schemas.openxmlformats.org/officeDocument/2006/math).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.officeDocument.x2006.math.STSpacingRule.
 */
public class STSpacingRuleImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements org.openxmlformats.schemas.officeDocument.x2006.math.STSpacingRule
{
    
    public STSpacingRuleImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STSpacingRuleImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
