/*
 * XML Type:  ST_Guid
 * Namespace: http://schemas.openxmlformats.org/officeDocument/2006/customXml
 * Java type: org.openxmlformats.schemas.officeDocument.x2006.customXml.STGuid
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.officeDocument.x2006.customXml.impl;
/**
 * An XML ST_Guid(@http://schemas.openxmlformats.org/officeDocument/2006/customXml).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.officeDocument.x2006.customXml.STGuid.
 */
public class STGuidImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.openxmlformats.schemas.officeDocument.x2006.customXml.STGuid
{
    
    public STGuidImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STGuidImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
