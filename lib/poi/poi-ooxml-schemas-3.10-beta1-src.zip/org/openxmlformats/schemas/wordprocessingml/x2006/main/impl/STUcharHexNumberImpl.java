/*
 * XML Type:  ST_UcharHexNumber
 * Namespace: http://schemas.openxmlformats.org/wordprocessingml/2006/main
 * Java type: org.openxmlformats.schemas.wordprocessingml.x2006.main.STUcharHexNumber
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.wordprocessingml.x2006.main.impl;
/**
 * An XML ST_UcharHexNumber(@http://schemas.openxmlformats.org/wordprocessingml/2006/main).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.wordprocessingml.x2006.main.STUcharHexNumber.
 */
public class STUcharHexNumberImpl extends org.apache.xmlbeans.impl.values.JavaHexBinaryHolderEx implements org.openxmlformats.schemas.wordprocessingml.x2006.main.STUcharHexNumber
{
    
    public STUcharHexNumberImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STUcharHexNumberImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
