/*
 * XML Type:  ST_MarkerSize
 * Namespace: http://schemas.openxmlformats.org/drawingml/2006/chart
 * Java type: org.openxmlformats.schemas.drawingml.x2006.chart.STMarkerSize
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.drawingml.x2006.chart.impl;
/**
 * An XML ST_MarkerSize(@http://schemas.openxmlformats.org/drawingml/2006/chart).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.drawingml.x2006.chart.STMarkerSize.
 */
public class STMarkerSizeImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements org.openxmlformats.schemas.drawingml.x2006.chart.STMarkerSize
{
    
    public STMarkerSizeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STMarkerSizeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
