/*
 * XML Type:  ST_MarkerCoordinate
 * Namespace: http://schemas.openxmlformats.org/drawingml/2006/chartDrawing
 * Java type: org.openxmlformats.schemas.drawingml.x2006.chartDrawing.STMarkerCoordinate
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.drawingml.x2006.chartDrawing.impl;
/**
 * An XML ST_MarkerCoordinate(@http://schemas.openxmlformats.org/drawingml/2006/chartDrawing).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.drawingml.x2006.chartDrawing.STMarkerCoordinate.
 */
public class STMarkerCoordinateImpl extends org.apache.xmlbeans.impl.values.JavaDoubleHolderEx implements org.openxmlformats.schemas.drawingml.x2006.chartDrawing.STMarkerCoordinate
{
    
    public STMarkerCoordinateImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STMarkerCoordinateImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
