/*
 * XML Type:  ST_SecondPieSize
 * Namespace: http://schemas.openxmlformats.org/drawingml/2006/chart
 * Java type: org.openxmlformats.schemas.drawingml.x2006.chart.STSecondPieSize
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.drawingml.x2006.chart.impl;
/**
 * An XML ST_SecondPieSize(@http://schemas.openxmlformats.org/drawingml/2006/chart).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.drawingml.x2006.chart.STSecondPieSize.
 */
public class STSecondPieSizeImpl extends org.apache.xmlbeans.impl.values.JavaIntHolderEx implements org.openxmlformats.schemas.drawingml.x2006.chart.STSecondPieSize
{
    
    public STSecondPieSizeImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STSecondPieSizeImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
