/*
 * XML Type:  ST_PictureStackUnit
 * Namespace: http://schemas.openxmlformats.org/drawingml/2006/chart
 * Java type: org.openxmlformats.schemas.drawingml.x2006.chart.STPictureStackUnit
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.drawingml.x2006.chart.impl;
/**
 * An XML ST_PictureStackUnit(@http://schemas.openxmlformats.org/drawingml/2006/chart).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.drawingml.x2006.chart.STPictureStackUnit.
 */
public class STPictureStackUnitImpl extends org.apache.xmlbeans.impl.values.JavaDoubleHolderEx implements org.openxmlformats.schemas.drawingml.x2006.chart.STPictureStackUnit
{
    
    public STPictureStackUnitImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STPictureStackUnitImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
