/*
 * XML Type:  ST_RelationshipId
 * Namespace: http://schemas.openxmlformats.org/officeDocument/2006/relationships
 * Java type: org.openxmlformats.schemas.officeDocument.x2006.relationships.STRelationshipId
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.officeDocument.x2006.relationships.impl;
/**
 * An XML ST_RelationshipId(@http://schemas.openxmlformats.org/officeDocument/2006/relationships).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.officeDocument.x2006.relationships.STRelationshipId.
 */
public class STRelationshipIdImpl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.openxmlformats.schemas.officeDocument.x2006.relationships.STRelationshipId
{
    
    public STRelationshipIdImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STRelationshipIdImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
