/*
 * XML Type:  ST_TwipsMeasure
 * Namespace: http://schemas.openxmlformats.org/officeDocument/2006/math
 * Java type: org.openxmlformats.schemas.officeDocument.x2006.math.STTwipsMeasure
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.officeDocument.x2006.math.impl;
/**
 * An XML ST_TwipsMeasure(@http://schemas.openxmlformats.org/officeDocument/2006/math).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.officeDocument.x2006.math.STTwipsMeasure.
 */
public class STTwipsMeasureImpl extends org.apache.xmlbeans.impl.values.JavaLongHolderEx implements org.openxmlformats.schemas.officeDocument.x2006.math.STTwipsMeasure
{
    
    public STTwipsMeasureImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STTwipsMeasureImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
