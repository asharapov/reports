/*
 * XML Type:  ST_String255
 * Namespace: http://schemas.openxmlformats.org/officeDocument/2006/bibliography
 * Java type: org.openxmlformats.schemas.officeDocument.x2006.bibliography.STString255
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.officeDocument.x2006.bibliography.impl;
/**
 * An XML ST_String255(@http://schemas.openxmlformats.org/officeDocument/2006/bibliography).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.officeDocument.x2006.bibliography.STString255.
 */
public class STString255Impl extends org.apache.xmlbeans.impl.values.JavaStringHolderEx implements org.openxmlformats.schemas.officeDocument.x2006.bibliography.STString255
{
    
    public STString255Impl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STString255Impl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
