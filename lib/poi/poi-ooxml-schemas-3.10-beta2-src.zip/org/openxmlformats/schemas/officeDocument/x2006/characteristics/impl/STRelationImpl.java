/*
 * XML Type:  ST_Relation
 * Namespace: http://schemas.openxmlformats.org/officeDocument/2006/characteristics
 * Java type: org.openxmlformats.schemas.officeDocument.x2006.characteristics.STRelation
 *
 * Automatically generated - do not modify.
 */
package org.openxmlformats.schemas.officeDocument.x2006.characteristics.impl;
/**
 * An XML ST_Relation(@http://schemas.openxmlformats.org/officeDocument/2006/characteristics).
 *
 * This is an atomic type that is a restriction of org.openxmlformats.schemas.officeDocument.x2006.characteristics.STRelation.
 */
public class STRelationImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements org.openxmlformats.schemas.officeDocument.x2006.characteristics.STRelation
{
    
    public STRelationImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected STRelationImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
